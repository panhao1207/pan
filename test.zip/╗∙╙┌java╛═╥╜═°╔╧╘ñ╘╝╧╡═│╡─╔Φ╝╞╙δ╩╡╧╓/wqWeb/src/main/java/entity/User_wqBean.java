package entity;

import java.io.Serializable;
import java.sql.Timestamp;

public class User_wqBean implements Serializable{

	private static final long serialVersionUID = 1L;
	private int Uid_wq;
	private String Uname_wq;
	private String Utel_wq;
	private String Usex_wq;
	private String Uimg_wq;
	private String Uattr_wq;
	private String Ushenfenzheng_wq;
	private String Ujianjie_wq;
	private String Upwd_wq;
	private Timestamp UTime_wq;
	public int Uage_wq;
	public int UtypeId_wq;
	private String Ubianhao_wq;
	
	
	
	public int getUtypeId_wq() {
		return UtypeId_wq;
	}
	public void setUtypeId_wq(int utypeId_wq) {
		UtypeId_wq = utypeId_wq;
	}
	public String getUbianhao_wq() {
		return Ubianhao_wq;
	}
	public void setUbianhao_wq(String ubianhao_wq) {
		Ubianhao_wq = ubianhao_wq;
	}
	public int getUage_wq() {
		return Uage_wq;
	}
	public void setUage_wq(int uage_wq) {
		Uage_wq = uage_wq;
	}
	public int getUid_wq() {
		return Uid_wq;
	}
	public void setUid_wq(int uid_wq) {
		Uid_wq = uid_wq;
	}
	public String getUname_wq() {
		return Uname_wq;
	}
	public void setUname_wq(String uname_wq) {
		Uname_wq = uname_wq;
	}
	public String getUtel_wq() {
		return Utel_wq;
	}
	public void setUtel_wq(String utel_wq) {
		Utel_wq = utel_wq;
	}
	public String getUsex_wq() {
		return Usex_wq;
	}
	public void setUsex_wq(String usex_wq) {
		Usex_wq = usex_wq;
	}
	public String getUimg_wq() {
		return Uimg_wq;
	}
	public void setUimg_wq(String uimg_wq) {
		Uimg_wq = uimg_wq;
	}
	public String getUattr_wq() {
		return Uattr_wq;
	}
	public void setUattr_wq(String uattr_wq) {
		Uattr_wq = uattr_wq;
	}
	public String getUshenfenzheng_wq() {
		return Ushenfenzheng_wq;
	}
	public void setUshenfenzheng_wq(String ushenfenzheng_wq) {
		Ushenfenzheng_wq = ushenfenzheng_wq;
	}
	public String getUjianjie_wq() {
		return Ujianjie_wq;
	}
	public void setUjianjie_wq(String ujianjie_wq) {
		Ujianjie_wq = ujianjie_wq;
	}
	public String getUpwd_wq() {
		return Upwd_wq;
	}
	public void setUpwd_wq(String upwd_wq) {
		Upwd_wq = upwd_wq;
	}
	public Timestamp getUTime_wq() {
		return UTime_wq;
	}
	public void setUTime_wq(Timestamp uTime_wq) {
		UTime_wq = uTime_wq;
	}
	
	
	
	
}
